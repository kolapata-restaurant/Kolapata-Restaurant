# Kolapata Restaurant — Free Website

## Files
- index.html — complete responsive website
- assets/logo.jpg — uploaded Kolapata logo
- assets/menu.jpg — uploaded menu image

## Publish for free with GitHub Pages
1. Create a free GitHub account.
2. Create a new PUBLIC repository, for example: `kolapata-restaurant`.
3. Upload `index.html` and the `assets` folder.
4. Open repository Settings → Pages.
5. Under Build and deployment, choose "Deploy from a branch".
6. Select `main` and `/ (root)`, then Save.
7. GitHub will give you a free address similar to:
   `https://YOUR-USERNAME.github.io/kolapata-restaurant/`

## Important
The address and phone currently use the information supplied in the conversation. Replace them in `index.html` if the final address/phone differs.
